﻿
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web;

public class Attachment : IHttpHandler
{
    private string ConnString
    {
        get
        {
            var css = ConfigurationManager.ConnectionStrings["TicketDb"];
            if (css == null || string.IsNullOrEmpty(css.ConnectionString))
                throw new Exception("Nedostaje TicketDb connection string.");
            return css.ConnectionString;
        }
    }

    public bool IsReusable { get { return true; } }

    public void ProcessRequest(HttpContext context)
    {
        if (context == null) return;

        // samo autentifikovani
        if (context.User == null || !context.User.Identity.IsAuthenticated)
        {
            context.Response.StatusCode = 401;
            return;
        }

        long id;
        long.TryParse(context.Request["id"], out id);
        if (id <= 0)
        {
            context.Response.StatusCode = 400;
            context.Response.Write("Bad Request");
            return;
        }

        // provera prava: admin grupa ili reporter/assignee
        int currentUserId = GetOrCreateCurrentUserId(context);

        string adminGroup = ConfigurationManager.AppSettings["Ticket.AdminGroup"]; // npr. "DOMAIN\\TicketAdmins"
        bool isAdmin = !string.IsNullOrWhiteSpace(adminGroup) && context.User.IsInRole(adminGroup);

        AttachmentRow a = GetAttachmentRow(id);
        if (a == null)
        {
            context.Response.StatusCode = 404;
            return;
        }

        if (!isAdmin)
        {
            // samo reporter ili assignee mogu
            if (a.ReporterId != currentUserId && a.AssigneeId != currentUserId)
            {
                context.Response.StatusCode = 403;
                return;
            }
        }

        // map path
        if (string.IsNullOrWhiteSpace(a.StoragePath))
        {
            context.Response.StatusCode = 404;
            return;
        }

        string rel = a.StoragePath.Trim();
        string abs = rel;

        // podrži i "~/", i relativne putanje, i apsolutne
        if (rel.StartsWith("~/"))
            abs = context.Server.MapPath(rel);
        else if (!Path.IsPathRooted(rel))
            abs = context.Server.MapPath("~/" + rel.TrimStart('/'));

        if (!File.Exists(abs))
        {
            context.Response.StatusCode = 404;
            return;
        }

        context.Response.Clear();
        context.Response.ContentType = string.IsNullOrWhiteSpace(a.ContentType)
            ? "application/octet-stream"
            : a.ContentType;

        string safeName = string.IsNullOrWhiteSpace(a.FileName) ? ("attachment_" + id) : a.FileName;
        safeName = safeName.Replace("\"", ""); // minimalno sanitizovanje

        context.Response.AddHeader("Content-Disposition", "inline; filename=\"" + safeName + "\"");
        context.Response.TransmitFile(abs);
        context.Response.Flush();

        // Response.End ume da baca ThreadAbortException; CompleteRequest je čistije
        context.ApplicationInstance.CompleteRequest();
    }

    private int GetOrCreateCurrentUserId(HttpContext context)
    {
        string login = context.User.Identity.Name;
        string username = LdapUserProvisioner.Normalize(login);

        using (SqlConnection cn = new SqlConnection(ConnString))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand("SELECT Id FROM ts.UserAccount WHERE Username=@u", cn))
            {
                cmd.Parameters.Add("@u", SqlDbType.NVarChar, 150).Value = username;
                object o = cmd.ExecuteScalar();
                if (o != null && o != DBNull.Value) return Convert.ToInt32(o);
            }

            using (SqlCommand cmd = new SqlCommand(@"
INSERT INTO ts.UserAccount (Username, LoginName, IsActive, CreatedAt, UpdatedAt)
VALUES (@u, @login, 1, SYSUTCDATETIME(), SYSUTCDATETIME());
SELECT SCOPE_IDENTITY();", cn))
            {
                cmd.Parameters.Add("@u", SqlDbType.NVarChar, 150).Value = username;


                cmd.Parameters.Add("@login", SqlDbType.NVarChar, 200).Value =
                    string.IsNullOrEmpty(login) ? (object)DBNull.Value : login;


                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }
    }

    private class AttachmentRow
    {
        public string StoragePath;
        public string FileName;
        public string ContentType;
        public int ReporterId;
        public int AssigneeId;
    }

    private AttachmentRow GetAttachmentRow(long attachmentId)
    {
        using (SqlConnection cn = new SqlConnection(ConnString))
        using (SqlCommand cmd = new SqlCommand(@"
SELECT a.StoragePath, a.FileName, a.ContentType,
       t.ReporterId, ISNULL(t.AssigneeId,0) AS AssigneeId
FROM ts.TicketAttachment a
JOIN ts.Ticket t ON t.Id = a.TicketId
WHERE a.Id = @id;", cn))
        {
            cmd.Parameters.Add("@id", SqlDbType.BigInt).Value = attachmentId;
            cn.Open();
            using (SqlDataReader rd = cmd.ExecuteReader())
            {
                if (!rd.Read()) return null;

                return new AttachmentRow
                {
                    StoragePath = rd["StoragePath"] == DBNull.Value ? null : rd["StoragePath"].ToString(),
                    FileName = rd["FileName"] == DBNull.Value ? null : rd["FileName"].ToString(),
                    ContentType = rd["ContentType"] == DBNull.Value ? null : rd["ContentType"].ToString(),
                    ReporterId = rd["ReporterId"] == DBNull.Value ? 0 : Convert.ToInt32(rd["ReporterId"]),
                    AssigneeId = rd["AssigneeId"] == DBNull.Value ? 0 : Convert.ToInt32(rd["AssigneeId"])
                };
            }
        }
    }
}
