﻿
using System;
using System.Configuration;
using System.IO;
using System.Net;
using System.Text;
using System.Web.Script.Serialization;
using System.Collections;
using System.Collections.Generic;

public static class JiraClient
{
    private static string BaseUrl
    {
        get
        {
            string u = ConfigurationManager.AppSettings["Jira.BaseUrl"];
            if (string.IsNullOrEmpty(u)) throw new Exception("Jira.BaseUrl nije podešen u web.config.");
            return u.TrimEnd('/') + "/";
        }
    }

    private static string Email
    {
        get
        {
            string e = ConfigurationManager.AppSettings["Jira.Email"];
            if (string.IsNullOrEmpty(e)) throw new Exception("Jira.Email nije podešen u web.config.");
            return e;
        }
    }

    private static string Token
    {
        get
        {
            string t = ConfigurationManager.AppSettings["Jira.ApiToken"];
            if (string.IsNullOrEmpty(t)) throw new Exception("Jira.ApiToken nije podešen u web.config.");
            return t;
        }
    }

    private static JavaScriptSerializer _js = new JavaScriptSerializer();

    private static HttpWebRequest MakeRequest(string relativePath, string method, bool json, string body)
    {

        System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072; // TLS 1.2
        System.Net.ServicePointManager.Expect100Continue = false;
        System.Net.ServicePointManager.CheckCertificateRevocationList = true;


        string url = BaseUrl + relativePath.TrimStart('/');
        HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
        req.Method = method;
        string auth = Convert.ToBase64String(Encoding.ASCII.GetBytes(Email + ":" + Token));
        req.Headers["Authorization"] = "Basic " + auth;
        req.Accept = "application/json";
        if (json)
        {
            req.ContentType = "application/json; charset=utf-8";
            if (!string.IsNullOrEmpty(body))
            {
                byte[] bytes = Encoding.UTF8.GetBytes(body);
                req.ContentLength = bytes.Length;
                using (var rs = req.GetRequestStream())
                {
                    rs.Write(bytes, 0, bytes.Length);
                }
            }
        }
        else
        {
            if (!string.IsNullOrEmpty(body))
            {
                byte[] bytes = Encoding.UTF8.GetBytes(body);
                req.ContentLength = bytes.Length;
                using (var rs = req.GetRequestStream())
                {
                    rs.Write(bytes, 0, bytes.Length);
                }
            }
        }
        return req;
    }

    private static string ReadResponse(HttpWebRequest req)
    {
        try
        {
            using (var resp = (HttpWebResponse)req.GetResponse())
            using (var sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
            {
                return sr.ReadToEnd();
            }
        }
        catch (WebException ex)
        {
            string error = "";
            try
            {
                if (ex.Response != null)
                {
                    using (var sr = new StreamReader(ex.Response.GetResponseStream(), Encoding.UTF8))
                    {
                        error = sr.ReadToEnd();
                    }
                }
            }
            catch { }
            throw new Exception("HTTP error: " + ex.Message + (string.IsNullOrEmpty(error) ? "" : (" | " + error)));
        }
    }

    private static string Serialize(object o) { return _js.Serialize(o); }

    // Minimalni ADF (v3 API očekuje ADF za description/comment)
    // https://developer.atlassian.com/cloud/jira/platform/rest/v3/
    private static object AdfFromPlain(string text)
    {
        Dictionary<string, object> doc = new Dictionary<string, object>();
        doc["type"] = "doc";
        doc["version"] = 1;

        Dictionary<string, object> paragraph = new Dictionary<string, object>();
        paragraph["type"] = "paragraph";

        Dictionary<string, object> textNode = new Dictionary<string, object>();
        textNode["type"] = "text";
        textNode["text"] = text ?? "";

        paragraph["content"] = new object[] { textNode };
        doc["content"] = new object[] { paragraph };
        return doc;
    }

    /// <summary>
    /// Kreira Jira issue i vraća (key, id). Koristi Jira.ProjectKey i Jira.IssueTypeName iz web.config-a.
    /// </summary>
    public static Tuple<string, string> CreateIssue(string projectKey, string issueTypeName, string summary, string descriptionPlain, string[] labels)
    {
        if (projectKey == null) throw new ArgumentNullException("projectKey");
        if (issueTypeName == null) throw new ArgumentNullException("issueTypeName");

        // fields objekt
        Dictionary<string, object> fields = new Dictionary<string, object>();
        fields["project"] = new Dictionary<string, object> { { "key", projectKey } };
        fields["issuetype"] = new Dictionary<string, object> { { "name", issueTypeName } };
        fields["summary"] = summary;
        fields["description"] = AdfFromPlain(descriptionPlain);
        if (labels != null) fields["labels"] = labels;

        Dictionary<string, object> root = new Dictionary<string, object>();
        root["fields"] = fields;

        string payload = Serialize(root);

        HttpWebRequest req = MakeRequest("rest/api/3/issue", "POST", true, payload);
        string txt = ReadResponse(req);

        // očekuje se { "id":"10001", "key":"IT-123", ... }
        Dictionary<string, object> d = _js.Deserialize<Dictionary<string, object>>(txt);
        string id = d.ContainsKey("id") && d["id"] != null ? d["id"].ToString() : null;
        string key = d.ContainsKey("key") && d["key"] != null ? d["key"].ToString() : null;
        if (string.IsNullOrEmpty(key) || string.IsNullOrEmpty(id))
            throw new Exception("Neočekivan odgovor Jira create issue: " + txt);

        return new Tuple<string, string>(key, id);
    }

    /// <summary>
    /// Dodaje plain-text komentar (ADF) na postojeći issue.
    /// </summary>
    public static void AddComment(string issueKey, string commentPlain)
    {
        if (string.IsNullOrEmpty(issueKey)) return;

        Dictionary<string, object> root = new Dictionary<string, object>();
        root["body"] = AdfFromPlain(commentPlain);
        string payload = Serialize(root);

        HttpWebRequest req = MakeRequest("rest/api/3/issue/" + Uri.EscapeDataString(issueKey) + "/comment", "POST", true, payload);
        string txt = ReadResponse(req);
        // ništa posebno ne vraćamo; greška bi izletela kroz exception
    }

    /// <summary>
    /// Prebacuje issue u status sa navedenim imenom (traži odgovarajuću transition).
    /// </summary>
    public static void TransitionToStatus(string issueKey, string desiredStatusName)
    {
        if (string.IsNullOrEmpty(issueKey) || string.IsNullOrEmpty(desiredStatusName)) return;

        // 1) GET transitions
        HttpWebRequest reqGet = MakeRequest("rest/api/3/issue/" + Uri.EscapeDataString(issueKey) + "/transitions", "GET", false, null);
        string txt = ReadResponse(reqGet);

        Dictionary<string, object> data = _js.Deserialize<Dictionary<string, object>>(txt);
        object transitionsObj;
        if (!data.TryGetValue("transitions", out transitionsObj) || transitionsObj == null)
            throw new Exception("Nije pronađena lista transitions za issue " + issueKey + ". Odgovor: " + txt);

        object[] transitions = transitionsObj as object[];
        if (transitions == null || transitions.Length == 0)
            throw new Exception("Prazna lista transitions za issue " + issueKey + ".");

        string transitionId = null;

        for (int i = 0; i < transitions.Length; i++)
        {
            Dictionary<string, object> tr = transitions[i] as Dictionary<string, object>;
            if (tr == null) continue;

            object toObj;
            if (!tr.TryGetValue("to", out toObj) || toObj == null) continue;

            Dictionary<string, object> to = toObj as Dictionary<string, object>;
            if (to == null) continue;

            object nameObj;
            if (to.TryGetValue("name", out nameObj) && nameObj != null)
            {
                string toName = nameObj.ToString();
                if (string.Equals(toName, desiredStatusName, StringComparison.OrdinalIgnoreCase))
                {
                    object idObj;
                    if (tr.TryGetValue("id", out idObj) && idObj != null)
                    {
                        transitionId = idObj.ToString();
                        break;
                    }
                }
            }
        }

        if (string.IsNullOrEmpty(transitionId))
            throw new Exception("Nije nađena Jira transition ka statusu '" + desiredStatusName + "'.");

        // 2) POST transition
        Dictionary<string, object> root = new Dictionary<string, object>();
        root["transition"] = new Dictionary<string, object> { { "id", transitionId } };
        string payload = Serialize(root);

        HttpWebRequest reqPost = MakeRequest("rest/api/3/issue/" + Uri.EscapeDataString(issueKey) + "/transitions", "POST", true, payload);
        string txt2 = ReadResponse(reqPost);
        // uspeh je 204, neki proxy vraćaju prazan body; greške bi bacile exception
    }
}
