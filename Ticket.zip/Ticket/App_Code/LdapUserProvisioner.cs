﻿
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.DirectoryServices;
using System.Web;

/// <summary>
/// LDAP JIT provisioning za Windows-auth WebForms aplikaciju (LDAP-only varijanta).
/// - Bez System.DirectoryServices.AccountManagement (nije potrebno)
/// - Kompatibilno sa starijim C# (nema =>, nema tuples)
/// - Oslanja se na connectionStrings["TicketDb"] i appSettings (Ldap.*)
/// </summary>
public static class LdapUserProvisioner
{
    // --- CONFIG ---

    private static string ConnString
    {
        get
        {
            ConnectionStringSettings css = ConfigurationManager.ConnectionStrings["TicketDb"];
            if (css == null || string.IsNullOrEmpty(css.ConnectionString))
                throw new Exception("Nedostaje connectionStrings[\"TicketDb\"] u web.config.");
            return css.ConnectionString;
        }
    }

    // --- PUBLIC API ---

    /// <summary>
    /// Proveri da je korisnik autentifikovan (Windows auth), obezbedi zapis u ts.UserAccount (JIT),
    /// popuni email/displayName/employeeId iz AD-a (LDAP), postavi IsActive=1.
    /// Ako je nalog deaktiviran u bazi, baca UnauthorizedAccessException.
    /// </summary>
    public static void EnsureCurrentUser(HttpContext context)
    {
        if (context == null || context.User == null || context.User.Identity == null || !context.User.Identity.IsAuthenticated)
            throw new UnauthorizedAccessException("Korisnik nije autentifikovan (Windows auth je potreban).");

        string login = context.User.Identity.Name;  // npr. "komora\\milan.jelic"
        string username = Normalize(login);         // npr. "milan.jelic"

        if (string.IsNullOrEmpty(username))
            throw new UnauthorizedAccessException("Nije moguće normalizovati korisničko ime iz Windows identiteta.");

        // 1) Postojeći korisnik?
        int? userId = null;
        bool? isActive = null;

        using (SqlConnection cn = new SqlConnection(ConnString))
        using (SqlCommand cmd = new SqlCommand("SELECT TOP 1 Id, IsActive FROM ts.UserAccount WHERE Username=@u", cn))
        {
            cmd.Parameters.Add("@u", SqlDbType.NVarChar, 150).Value = username;
            cn.Open();
            using (SqlDataReader rd = cmd.ExecuteReader())
            {
                if (rd.Read())
                {
                    userId = rd.GetInt32(0);
                    isActive = rd.GetBoolean(1);
                }
            }
        }

        if (userId.HasValue)
        {
            if (isActive.HasValue && !isActive.Value)
                throw new UnauthorizedAccessException("Nalog je deaktiviran u ticketing sistemu.");
            // (opciono) ovde može da ide lazy-refresh iz AD-a po vremenskom intervalu
            return;
        }

        // 2) Novi korisnik -> pokušaj LDAP upit
        AdInfo info = QueryAdBySam_LdapOnly(username);

        using (SqlConnection cn = new SqlConnection(ConnString))
        using (SqlCommand cmd = new SqlCommand(@"
INSERT INTO ts.UserAccount
    (Username, LoginName, Email, DisplayName, ExternalEmployeeId, IsActive, CreatedAt, UpdatedAt)
VALUES
    (@Username, @LoginName, @Email, @DisplayName, @EmployeeId, @IsActive, SYSUTCDATETIME(), SYSUTCDATETIME());", cn))
        {
            cmd.Parameters.Add("@Username", SqlDbType.NVarChar, 150).Value = username;
            cmd.Parameters.Add("@LoginName", SqlDbType.NVarChar, 200).Value = (object)login ?? DBNull.Value;
            cmd.Parameters.Add("@Email", SqlDbType.NVarChar, 256).Value = (object)info.Email ?? DBNull.Value;
            cmd.Parameters.Add("@DisplayName", SqlDbType.NVarChar, 200).Value =
                (object)(string.IsNullOrEmpty(info.DisplayName) ? username : info.DisplayName) ?? DBNull.Value;
            cmd.Parameters.Add("@EmployeeId", SqlDbType.NVarChar, 50).Value = (object)info.EmployeeId ?? DBNull.Value;
            cmd.Parameters.Add("@IsActive", SqlDbType.Bit).Value = info.Enabled.HasValue ? (info.Enabled.Value ? 1 : 0) : 1;

            cn.Open();
            cmd.ExecuteNonQuery();
        }
    }

    /// <summary>
    /// "komora\milan.jelic" -> "milan.jelic"; "user@firma.rs" -> "user"
    /// </summary>
    public static string Normalize(string login)
    {
        if (string.IsNullOrEmpty(login)) return string.Empty;

        string u = login.Trim();
        int slash = u.IndexOf('\\');
        if (slash >= 0 && slash + 1 < u.Length) u = u.Substring(slash + 1);
        int at = u.IndexOf('@');
        if (at > 0) u = u.Substring(0, at);

        return u.Trim().ToLowerInvariant();
    }

    // --- LDAP ONLY IMPLEMENTACIJA ---

    /// <summary>
    /// LDAP upit preko System.DirectoryServices (bez AccountManagement).
    /// </summary>
    private static AdInfo QueryAdBySam_LdapOnly(string sam)
    {
        AdInfo result = new AdInfo();

        try
        {
            string domain = ConfigurationManager.AppSettings["Ldap.Domain"];
            if (string.IsNullOrEmpty(domain)) domain = "komora";

            // Najčešće "LDAP://komora" radi; po potrebi promeni na konkretnog DC-a, npr. "LDAP://DC01.komora.local"
            string ldapPath = "LDAP://" + domain;

            string svcUser = ConfigurationManager.AppSettings["Ldap.ServiceUser"];
            string svcPass = ConfigurationManager.AppSettings["Ldap.ServicePassword"];
            bool useSvc = false;
            string useSvcRaw = ConfigurationManager.AppSettings["Ldap.UseServiceAccount"];
            if (!string.IsNullOrEmpty(useSvcRaw))
                useSvc = string.Equals(useSvcRaw, "true", StringComparison.OrdinalIgnoreCase);

            DirectoryEntry root = useSvc
                ? new DirectoryEntry(ldapPath, svcUser, svcPass)
                : new DirectoryEntry(ldapPath);

            DirectorySearcher ds = new DirectorySearcher(root);
            ds.Filter = "(&(objectClass=user)(sAMAccountName=" + EscapeLdap(sam) + "))";
            ds.PropertiesToLoad.Add("mail");
            ds.PropertiesToLoad.Add("displayName");
            ds.PropertiesToLoad.Add("employeeID");
            ds.PropertiesToLoad.Add("userAccountControl");

            SearchResult sr = ds.FindOne();
            if (sr != null)
            {
                result.Email = GetProp(sr, "mail");
                result.DisplayName = GetProp(sr, "displayName");
                result.EmployeeId = GetProp(sr, "employeeID");

                // userAccountControl flag: 0x0002 = ACCOUNTDISABLE (set bit -> disabled)
                int uac;
                string uacStr = GetProp(sr, "userAccountControl");
                if (Int32.TryParse(uacStr, out uac))
                    result.Enabled = (uac & 0x0002) == 0;
                else
                    result.Enabled = true;
            }
            else
            {
                result.Enabled = true; // ako nije nađen, ne blokiraj aplikaciju
            }

            // Dispose nije striktno potreban jer se GC pobrine, ali:
            try { if (root != null) root.Dispose(); } catch { }
            try { if (ds != null) ds.Dispose(); } catch { }
        }
        catch
        {
            result.Email = null;
            result.DisplayName = null;
            result.EmployeeId = null;
            result.Enabled = true; // fallback
        }

        return result;
    }

    // --- Pomoćne metode / DTO ---

    private static string GetProp(SearchResult sr, string name)
    {
        if (sr.Properties.Contains(name) && sr.Properties[name].Count > 0)
            return Convert.ToString(sr.Properties[name][0]);
        return null;
    }

    private static string EscapeLdap(string input)
    {
        if (string.IsNullOrEmpty(input)) return input;
        return input.Replace("\\", "\\5c").Replace("*", "\\2a").Replace("(", "\\28").Replace(")", "\\29").Replace("\0", "\\00");
    }

    private sealed class AdInfo
    {
        public string Email;
        public string DisplayName;
        public string EmployeeId;
        public bool? Enabled;
    }
}
