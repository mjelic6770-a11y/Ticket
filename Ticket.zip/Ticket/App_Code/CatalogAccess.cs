using System;
using System.Data;
using System.Data.Common;

[Serializable()]
public struct Materijal
{
    public int[] ID;
    public string[] naziv, jedinicaMere;
}

/// <summary>
/// Product catalog business tier component
/// </summary>
public static class CatalogAccess
{        
    static CatalogAccess()
    {
        //
        // TODO: Add constructor logic here
        //
    }


    public static Materijal GetMaterijal()
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "NabavkeGetMaterijal";

        DataTable table = GenericDataAccess.ExecuteSelectCommand(comm);
        Materijal details = new Materijal();

        details.ID = new int[table.Rows.Count];
        details.naziv = new string[table.Rows.Count];
        details.jedinicaMere = new string[table.Rows.Count];

        if (table.Rows.Count > 0)
        {
            for (int i = 0; i < table.Rows.Count; i++)
            {
                details.ID[i] = Convert.ToInt32(table.Rows[i]["ID"].ToString());
                details.naziv[i] = table.Rows[i]["naziv"].ToString();
                details.jedinicaMere[i] = table.Rows[i]["jedinicaMere"].ToString();            
            }
        }

        return details;
    }

    public static DataTable GetMaterijali()
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "NabavkeGetMaterijali";

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetJedMere(int materijalID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "NabavkeGetJedMere";

        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@materijalID";
        param.Value = materijalID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);  
    }

    public static DataTable GetOrgJed(string userAD)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "NabavkeGetOrgJed";

        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@userAD";
        param.Value = userAD;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable InsertTrebovanje(int OJID, int radnikID, int mesec, int godina, string napomena)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "NabavkeInsertTrebovanje";

        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@OJID";
        param.Value = OJID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@radnikID";
        param.Value = radnikID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@mesec";
        param.Value = mesec;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@godina";
        param.Value = godina;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@napomena";
        param.Value = napomena;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    
    public static bool InsertTrebovanjeStavke(int trebovanjeID, string strXML)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "NabavkeInsertTrebovanjeStavke";

        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@trebovanjeID";
        param.Value = trebovanjeID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@strXML";
        param.Value = strXML;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        int result = -1;
        try
        {
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {

        }

        return (result >= 1);
    }

    public static bool DeleteTrebovanjeStavke(int trebovanjeID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "NabavkeDeleteTrebovanjeStavke";

        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@trebovanjeID";
        param.Value = trebovanjeID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        int result = -1;
        try
        {
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {

        }

        return (result >= 1);
    }

    public static bool UpdateTrebovanje(int ojid, int mesecTrebovanja, int godinaTrebovanja, string napomena)
    { 
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "NabavkeUpdateTrebovanje";

        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ojid";
        param.Value = ojid;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@mesecTrebovanja";
        param.Value = mesecTrebovanja;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@godinaTrebovanja";
        param.Value = godinaTrebovanja;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@napomena";
        param.Value = napomena;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        int result = -1;
        try
        {
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {

        }

        return (result >= 1);
    }

    public static DataTable GetTrebovanje(int OJID, int mesecTrebovanja, int godinaTrebovanja)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "NabavkeGetTrebovanje";

        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@OJID";
        param.Value = OJID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@mesecTrebovanja";
        param.Value = mesecTrebovanja;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@godinaTrebovanja";
        param.Value = godinaTrebovanja;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetNarudzbinu(int OJID, int mesecTrebovanja, int godinaTrebovanja)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "NabavkeGetNarudzbinu";

        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@OJID";
        param.Value = OJID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@mesecTrebovanja";
        param.Value = mesecTrebovanja;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@godinaTrebovanja";
        param.Value = godinaTrebovanja;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetSveNarudzbine(int mesecTrebovanja, int godinaTrebovanja)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "NabavkeGetSveNarudzbine";

        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@mesecTrebovanja";
        param.Value = mesecTrebovanja;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@godinaTrebovanja";
        param.Value = godinaTrebovanja;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static bool DeleteTrebovanjeStavka(int stavkaID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "NabavkeDeleteTrebovanjeStavka";

        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@stavkaID";
        param.Value = stavkaID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        int result = -1;
        try
        {
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {

        }

        return (result >= 1);
    }

    public static bool InsertMaterijal(int sifra, string naziv, string jedinicaMere)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "NabavkeInsertMaterijal";

        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@sifra";
        param.Value = sifra;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@naziv";
        param.Value = naziv;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@jedinicaMere";
        param.Value = jedinicaMere;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        int result = -1;
        try
        {
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {

        }

        return (result >= 1);
    }

    public static bool DeleteMaterijal(int materijalID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "NabavkeDeleteMaterijal";

        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@materijalID";
        param.Value = materijalID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);
        
        int result = -1;
        try
        {
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {

        }

        return (result >= 1);
    }

    public static bool UpdateMaterijal(int materijalID, string sifra, string naziv, string jedinicaMere)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "NabavkeUpdateMaterijal";

        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@materijalID";
        param.Value = materijalID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@sifra";
        param.Value = sifra;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@naziv";
        param.Value = naziv;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@jedinicaMere";
        param.Value = jedinicaMere;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        int result = -1;
        try
        {
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {

        }

        return (result >= 1);
    }

    




    //public static PodnesakOdredjeni GetPodnesakOdredjeni(string id,string sifra)
    //{
    //    DbCommand comm = GenericDataAccess.CreateCommand();
    //    comm.CommandText = "ElektronskiDnevnikGetPodnesakOdredjeni";

    //    DbParameter param = comm.CreateParameter();
    //    //create new parameter
    //    param = comm.CreateParameter();
    //    param.ParameterName = "@id";
    //    param.Value = id;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@sifra";
    //    param.Value = sifra;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //     DataTable table = GenericDataAccess.ExecuteSelectCommand(comm);
    //    //wrap retrieved data into CategoryDetails object
    //    PodnesakOdredjeni details = new PodnesakOdredjeni();
    //    if (table.Rows.Count > 0)
    //    {
    //        details.Sadrzaj = table.Rows[0]["Sadrzaj"].ToString();
    //        details.Datum = table.Rows[0]["Datum"].ToString();
    //        details.Ime = table.Rows[0]["Ime"].ToString();
    //        details.NapomenaPodneskaBaza = table.Rows[0]["NapomenaPodneskaBaza"].ToString();
    //    }
    //    return details;
    //}
    

    //public static DataTable GetListaPreduzeca(string naziv, string naselje, string mbr)
    //{
    //    DbCommand comm = GenericDataAccess.CreateCommand();
    //    comm.CommandText = "ElektronskiDnevnikGetListaPreduzeca";

    //    DbParameter param = comm.CreateParameter();
    //    //create new parameter
    //    param = comm.CreateParameter();
    //    param.ParameterName = "@naziv";
    //    param.Value = naziv;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@naselje";
    //    param.Value = naselje;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@mbr";
    //    param.Value = mbr;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    return GenericDataAccess.ExecuteSelectCommand(comm);
    //}



    //public static DataTable UpdatePredmetOkoncanje(string ID, string DatumOkoncanja, string NacinOkoncanja, string Izvrsnost)
    //{
    //    DbCommand comm = GenericDataAccess.CreateCommand();
    //    comm.CommandText = "ElektronskiDnevnikUpdatePredmetOkoncanje";

    //    DbParameter param = comm.CreateParameter();
    //    //create new parameter
    //    param = comm.CreateParameter();
    //    param.ParameterName = "@ID";
    //    param.Value = ID;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@DatumOkoncanja";
    //    param.Value = DatumOkoncanja;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@NacinOkoncanja";
    //    param.Value = NacinOkoncanja;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@Izvrsnost";
    //    param.Value = Izvrsnost;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

        
    //    return GenericDataAccess.ExecuteSelectCommand(comm);
    //}

    

    
    //public static bool DeleteSertifikat(int ElektronskiDnevnikD)
    //{
    //    DbCommand comm = GenericDataAccess.CreateCommand();
    //    comm.CommandText = "ElektronskiDnevnikDeleteSertifikat";

    //    //create new parameter
    //    DbParameter param = comm.CreateParameter();
    //    param.ParameterName = "@ElektronskiDnevnikD";
    //    param.Value = ElektronskiDnevnikD;
    //    param.DbType = DbType.Int32;
    //    comm.Parameters.Add(param);

    //    // result will represent the number of changed rows
    //    int result = -1;
    //    try
    //    {
    //        // execute the stored procedure
    //        result = GenericDataAccess.ExecuteNonQuery(comm);
    //    }
    //    catch
    //    {
    //        // any errors are logged in GenericDataAccess, we ingore them here
    //    }
    //    // result will be 1 in case of success 
    //    return (result >= 1);
    //}


    //public static Predmet GetPredmetSve(string BrojPredmeta)
    //{
    //    DbCommand comm = GenericDataAccess.CreateCommand();
    //    comm.CommandText = "ElektronskiDnevnikGetPredmetSve";
    //    DbParameter param = comm.CreateParameter();
    //    //create new parameter
    //    param = comm.CreateParameter();
    //    param.ParameterName = "@BrojPredmeta";
    //    param.Value = BrojPredmeta;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);
    //    DataTable table = GenericDataAccess.ExecuteSelectCommand(comm);
    //    //wrap retrieved data into CategoryDetails object
    //    Predmet details = new Predmet();
    //    if (table.Rows.Count > 0)
    //    {
    //        details.ID3 = table.Rows[0]["ID3"].ToString();
    //        details.BrojPredmetaBaza = table.Rows[0]["BrojPredmetaBaza"].ToString();
    //        details.DatumPrijema = table.Rows[0]["DatumPrijema"].ToString();
    //        details.TuzilacIme = table.Rows[0]["TuzilacIme"].ToString();
    //        details.TuzilacAdresa = table.Rows[0]["TuzilacAdresa"].ToString();
    //        details.TuzilacTelefon = table.Rows[0]["TuzilacTelefon"].ToString();
    //        details.TuzilacZastupnikIme = table.Rows[0]["TuzilacZastupnikIme"].ToString();
    //        details.TuzilacZastupnikAdresa = table.Rows[0]["TuzilacZastupnikAdresa"].ToString();
    //        details.TuzilacZastupniktelefon = table.Rows[0]["TuzilacZastupniktelefon"].ToString();
    //        details.TuzeniIme = table.Rows[0]["TuzeniIme"].ToString();
    //        details.TuzeniAdresa = table.Rows[0]["TuzeniAdresa"].ToString();
    //        details.TuzeniTelefon = table.Rows[0]["TuzeniTelefon"].ToString();
    //        details.TuzeniZastupnikIme = table.Rows[0]["TuzeniZastupnikIme"].ToString();
    //        details.TuzeniZastupnikAdresa = table.Rows[0]["TuzeniZastupnikAdresa"].ToString();
    //        details.TuzeniZastupnikTelefon = table.Rows[0]["TuzeniZastupnikTelefon"].ToString();
    //        details.TuzilacZastupnikIme = table.Rows[0]["TuzilacZastupnikIme"].ToString();
    //        details.VrednostSpora = table.Rows[0]["VrednostSpora"].ToString();
    //        details.OsnovSpora = table.Rows[0]["OsnovSpora"].ToString();
    //        details.DatumOkoncanja = table.Rows[0]["DatumOkoncanja"].ToString();
    //        details.NacinOkoncanja = table.Rows[0]["NacinOkoncanja"].ToString();
    //        details.DatumIzvrsenja = table.Rows[0]["DatumIzvrsenja"].ToString();
    //        details.Napomena = table.Rows[0]["Napomena"].ToString();
    //        details.NapomenaZavrsna = table.Rows[0]["NapomenaZavrsna"].ToString();

    //    }
    //    return details;
    //}

    //public static bool InsertArbitraznoVece(string ID,string PredsednikIme, string PredsednikAdresa, string PredsednikTelefon, string ArbitarImeTuzioc, string ArbitarAdresaTuzioc, string ArbitarTelefonTuzioc, string ArbitarImeTuziocZ, string ArbitarAdresaTuziocZ, string ArbitarTelefonTuziocZ, string ArbitarImeTuzeni, string ArbitarAdresaTuzeni, string ArbitarTelefonTuzeni, string ArbitarImeTuzeniZ, string ArbitarAdresaTuzeniZ, string ArbitarTelefonTuzeniZ)
    //{
    //    DbCommand comm = GenericDataAccess.CreateCommand();
    //    comm.CommandText = "ElektronskiDnevnikInsertArbitraznoVece";

    //    //create new parameter
    //    DbParameter param = comm.CreateParameter();
    //    param.ParameterName = "@ID";
    //    param.Value = ID;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);
        
    //    param = comm.CreateParameter();
    //    param.ParameterName = "@PredsednikIme";
    //    param.Value = PredsednikIme;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@PredsednikAdresa";
    //    param.Value = PredsednikAdresa;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@PredsednikTelefon";
    //    param.Value = PredsednikTelefon;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@ArbitarImeTuzioc";
    //    param.Value = ArbitarImeTuzioc;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@ArbitarAdresaTuzioc";
    //    param.Value = ArbitarAdresaTuzioc;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@ArbitarTelefonTuzioc";
    //    param.Value = ArbitarTelefonTuzioc;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@ArbitarImeTuziocZ";
    //    param.Value = ArbitarImeTuziocZ;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@ArbitarAdresaTuziocZ";
    //    param.Value = ArbitarAdresaTuziocZ;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@ArbitarTelefonTuziocZ";
    //    param.Value = ArbitarTelefonTuziocZ;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@ArbitarImeTuzeni";
    //    param.Value = ArbitarImeTuzeni;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@ArbitarAdresaTuzeni";
    //    param.Value = ArbitarAdresaTuzeni;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@ArbitarTelefonTuzeni";
    //    param.Value = ArbitarTelefonTuzeni;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@ArbitarImeTuzeniZ";
    //    param.Value = ArbitarImeTuzeniZ;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@ArbitarAdresaTuzeniZ";
    //    param.Value = ArbitarAdresaTuzeniZ;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);

    //    param = comm.CreateParameter();
    //    param.ParameterName = "@ArbitarTelefonTuzeniZ";
    //    param.Value = ArbitarTelefonTuzeniZ;
    //    param.DbType = DbType.String;
    //    comm.Parameters.Add(param);


    //    // result will represent the number of changed rows
    //    int result = -1;
    //    try
    //    {
    //        // execute the stored procedure
    //        result = GenericDataAccess.ExecuteNonQuery(comm);
    //    }
    //    catch
    //    {
    //        // any errors are logged in GenericDataAccess, we ingore them here
    //    }
    //    // result will be 1 in case of success 
    //    return (result >= 1);
    //}
    
     
}